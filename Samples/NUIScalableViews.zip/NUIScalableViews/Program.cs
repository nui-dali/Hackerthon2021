﻿using System;
using Tizen.NUI;

namespace NUIScalableViews
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main(string[] args)
        {
            NUIScalableViews Instance = new NUIScalableViews();
            Instance.Run(args);
        }
    }
}
