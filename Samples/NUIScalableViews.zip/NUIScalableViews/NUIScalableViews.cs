﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Tizen.Applications;
using Tizen.NUI;
using Tizen.NUI.Components;
using Tizen.NUI.BaseComponents;
using Tizen.NUI.Xaml;
using NUIScalableViews.layout;

namespace NUIScalableViews
{
    public class NUIScalableViews : NUIApplication
    {
        private static readonly string LogTag = "TEST";

        private Window window;
        private View rootView, leftMargin, rightMargin;
        private View contentView, content1, content2;
        private TabView tabView;
        private View flexView;
        private View bottomView1, bottomView2;

        private FlexLayout flexLayout;
        override protected void OnCreate()
        {
            base.OnCreate();

            // NOTE To use theme.xaml, uncomment below line.
            // ThemeManager.ApplyTheme(new Theme(Tizen.Applications.Application.Current.DirectoryInfo.Resource + "theme/theme.xaml"));

            //GetDefaultWindow().Add(new Scene1Page());
            //GetDefaultWindow().KeyEvent += OnScene1KeyEvent;
            CreateWindow();
            CreateRootView();
            CreateContentView();
            CreateTabView();
        }

        private void CreateWindow()
        {
            // window
            window = GetDefaultWindow();
            //window.Title = "NUIScalableViews";
            window.BackgroundColor = Color.White;
            //window.BackgroundColor = new Color(0.196f, 0.196f, 0.196f, 1.0f);
            window.KeyEvent += OnKeyEvent;

            // flex page (source code)
            var winSize = window.WindowSize;

            flexLayout = new FlexLayout();
            flexLayout.Justification = FlexLayout.FlexJustification.FlexStart;
            flexLayout.Alignment = FlexLayout.AlignmentType.FlexStart;
            flexLayout.WrapType = FlexLayout.FlexWrapType.NoWrap;

            if (winSize.Width > winSize.Height || winSize.Width == winSize.Height)
            {
                // 가로모드
                flexLayout.Direction = FlexLayout.FlexDirection.Row;

            }
            else
            {
                // 세로모드
                flexLayout.Direction = FlexLayout.FlexDirection.Column;
            }
        }

        private void CreateRootView()
        {
            // root veiw (linear layout)
            rootView = new View();
            // 윈도우 사이즈 확인
            rootView.Size = new Size(window.Size);

            rootView.PositionUsesPivotPoint = true;
            rootView.ParentOrigin = ParentOrigin.Center;
            rootView.PivotPoint = PivotPoint.Center;
            rootView.WidthResizePolicy = ResizePolicyType.FillToParent;
            rootView.HeightResizePolicy = ResizePolicyType.FillToParent;

            LinearLayout rootLayout = new LinearLayout();
            rootLayout.LinearAlignment = LinearLayout.Alignment.Begin;
            rootLayout.LinearOrientation = LinearLayout.Orientation.Horizontal;

            rootView.Layout = rootLayout;

            window.Add(rootView);

            // left margin
            leftMargin = new View();
            //leftMargin.BackgroundColor = new Color(0.1f, 0.1f, 0.1f, 0.5f);
            leftMargin.WidthSpecification = LayoutParamPolicies.MatchParent;
            leftMargin.HeightSpecification = LayoutParamPolicies.MatchParent;
            leftMargin.Weight = 0.05f;

            // content view (linear layout)
            contentView = new View();
            contentView.WidthSpecification = LayoutParamPolicies.MatchParent;
            contentView.HeightSpecification = LayoutParamPolicies.MatchParent;
            contentView.Weight = 0.9f;

            LinearLayout contentLayout = new LinearLayout();
            contentLayout.LinearAlignment = LinearLayout.Alignment.Begin;
            contentLayout.LinearOrientation = LinearLayout.Orientation.Vertical;

            contentView.Layout = contentLayout;

            // right margin
            rightMargin = new View();
            //rightMargin.BackgroundColor = new Color(0.1f, 0.1f, 0.1f, 0.5f);
            rightMargin.WidthSpecification = LayoutParamPolicies.MatchParent;
            rightMargin.HeightSpecification = LayoutParamPolicies.MatchParent;
            rightMargin.Weight = 0.05f;

            rootView.Add(leftMargin);
            rootView.Add(contentView);
            rootView.Add(rightMargin);
        }

        private void CreateContentView()
        {
            content1 = new View();
            //content1.BackgroundColor = new Color(0.1f, 0.1f, 0.1f, 0.5f);
            content1.WidthSpecification = LayoutParamPolicies.MatchParent;
            content1.HeightSpecification = LayoutParamPolicies.MatchParent;
            content1.Weight = 0.09f;

            content2 = new View();
            //content1.BackgroundColor = new Color(0.5f, 0.5f, 0.5f, 0.5f);
            content2.WidthSpecification = LayoutParamPolicies.MatchParent;
            content2.HeightSpecification = LayoutParamPolicies.MatchParent;
            content2.Weight = 0.01f;

            contentView.Add(content1);
            contentView.Add(content2);
        }

        private void CreateTabView()
        {
            tabView = new TabView()
            {
                WidthSpecification = LayoutParamPolicies.MatchParent,
                HeightSpecification = LayoutParamPolicies.MatchParent,
            };

            int tabCount = 0;
            TabButton tabButton;
            View tabContent;

            for (int i = 1; i <= 4; ++i)
            {
                tabButton = new TabButton()
                {
                    Text = "Tab" + i.ToString(),
                };

                tabContent = new TextLabel()
                {
                    Text = "Content" + i.ToString(),
                    BackgroundColor = Color.White,
                    WidthSpecification = LayoutParamPolicies.MatchParent,
                    HeightSpecification = LayoutParamPolicies.MatchParent,
                    HorizontalAlignment = HorizontalAlignment.Center,
                    VerticalAlignment = VerticalAlignment.Center,
                };

                tabView.AddTab(tabButton, tabContent);
                tabCount++;

                if (i == 1)
                {
                    LinearLayout tabContentLayout = new LinearLayout();
                    tabContentLayout.LinearAlignment = LinearLayout.Alignment.Begin;
                    tabContentLayout.LinearOrientation = LinearLayout.Orientation.Vertical;

                    tabContent.Layout = tabContentLayout;

                    CreatetabContentView(tabContent);
                }
                // TEST
                if (i == 2)
                {
                    FlexLayout tab2ContentLayout = new FlexLayout();
                    tab2ContentLayout.Direction = FlexLayout.FlexDirection.Row;
                    tab2ContentLayout.Justification = FlexLayout.FlexJustification.FlexStart;
                    tab2ContentLayout.Alignment = FlexLayout.AlignmentType.FlexStart;

                    tabContent.Layout = tab2ContentLayout;

                    Tab2Page tab2Page = new Tab2Page();
                    tab2Page.WidthSpecification = LayoutParamPolicies.MatchParent;
                    tab2Page.HeightSpecification = LayoutParamPolicies.MatchParent;
                    
                    tabContent.Add(tab2Page);
                }
                if (i == 3)
                {
                    /*LinearLayout tab3ContentLayout = new LinearLayout();
                    tab3ContentLayout.LinearAlignment = LinearLayout.Alignment.Begin;
                    tab3ContentLayout.LinearOrientation = LinearLayout.Orientation.Vertical;

                    tabContent.Layout = tab3ContentLayout;*/

                    Tab3Page tab3Page = new Tab3Page();
                    tab3Page.WidthSpecification = LayoutParamPolicies.MatchParent;
                    tab3Page.HeightSpecification = LayoutParamPolicies.MatchParent;

                    tabContent.Add(tab3Page);
                }
            }

            content1.Add(tabView);
        }

        private void CreatetabContentView(View parent)
        {
            // top page
            TopPage topPage = new TopPage();
            topPage.Weight = 0.1f;
            topPage.WidthSpecification = LayoutParamPolicies.MatchParent;
            topPage.HeightSpecification = LayoutParamPolicies.MatchParent;

            parent.Add(topPage);

            // flex page (source code)
            flexView = new View();
           // flexView.BackgroundColor = new Color(0.8f, 0.1f, 0.1f, 0.5f);
            flexView.WidthSpecification = LayoutParamPolicies.MatchParent;
            flexView.HeightSpecification = LayoutParamPolicies.MatchParent;
            flexView.Weight = 0.9f;

            flexView.Layout = flexLayout;

            parent.Add(flexView);

            CreateFlexView(flexView);

            // flex page (xaml)
            /*FlexPage flexPage = new FlexPage();
            flexPage.BackgroundColor = new Color(0.8f, 0.1f, 0.1f, 0.5f);
            flexPage.WidthSpecification = LayoutParamPolicies.MatchParent;
            flexPage.HeightSpecification = LayoutParamPolicies.MatchParent;
            flexPage.Weight = 0.9f;

            parent.Add(flexPage);*/
        }
        void CreateFlexView(View parent)
        {
            FlexPage1 flexPage1 = new FlexPage1();
            flexPage1.WidthSpecification = LayoutParamPolicies.MatchParent;
            flexPage1.HeightSpecification = LayoutParamPolicies.MatchParent;

            FlexPage2 flexPage2 = new FlexPage2();
            flexPage2.WidthSpecification = LayoutParamPolicies.MatchParent;
            flexPage2.HeightSpecification = LayoutParamPolicies.MatchParent;

            parent.Add(flexPage1);
            parent.Add(flexPage2);
        }

        private void OnKeyEvent(object sender, Window.KeyEventArgs e)
        {
            if (e.Key.State == Key.StateType.Down && (e.Key.KeyPressedName == "XF86Back" || e.Key.KeyPressedName == "Escape"))
            {
                Exit();
            }
        }

        override protected void OnPause()
        {
            base.OnPause();
        }

        override protected void OnResume()
        {
            base.OnResume();
        }

        override protected void OnTerminate()
        {
            base.OnTerminate();
        }

        override protected void OnAppControlReceived(AppControlReceivedEventArgs e)
        {
            base.OnAppControlReceived(e);
        }
    }
}
