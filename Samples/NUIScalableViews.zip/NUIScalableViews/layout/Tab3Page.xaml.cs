﻿using Tizen.NUI;
using Tizen.NUI.BaseComponents;

namespace NUIScalableViews.layout
{
    public partial class Tab3Page : View
    {
        public Tab3Page()
        {
            InitializeComponent();
        }
    }
}
