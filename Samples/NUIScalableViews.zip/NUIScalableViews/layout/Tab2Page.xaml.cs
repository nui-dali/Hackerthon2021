﻿using Tizen.NUI;
using Tizen.NUI.BaseComponents;

namespace NUIScalableViews
{
    public partial class Tab2Page : View
    {
        public Tab2Page()
        {
            InitializeComponent();
        }
    }
}
