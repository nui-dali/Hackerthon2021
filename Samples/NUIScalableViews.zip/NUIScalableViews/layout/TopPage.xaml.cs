﻿using Tizen.NUI;
using Tizen.NUI.BaseComponents;

namespace NUIScalableViews
{
    public partial class TopPage : View
    {
        public TopPage()
        {
            InitializeComponent();
        }
    }
}
