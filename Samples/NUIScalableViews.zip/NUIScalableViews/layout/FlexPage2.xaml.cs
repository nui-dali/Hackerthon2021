﻿using System;
using Tizen.NUI;
using Tizen.NUI.BaseComponents;
using System.Collections.Generic;
using NUIScalableViews.layout;

namespace NUIScalableViews
{
    public partial class ListItemClickedEventArgs : EventArgs
    {
        public string ClickedItemText;
        public int Index;

        public ListItemClickedEventArgs(string text, int index)
        {
            ClickedItemText = text;
            Index = index;
        }
    }

    public class ListItem : TextLabel
    {
        private int Index = -1;
        public event EventHandler<ListItemClickedEventArgs> Clicked;

        public ListItem(string text, int index)
        {
            Text = text;
            Index = index;
            TouchEvent += OnTouchEvent;
            Size2D = new Tizen.NUI.Size2D(500, 50);
           
        }

        private bool OnTouchEvent(object sender, TouchEventArgs args)
        {
            if (args.Touch.GetState(0) == Tizen.NUI.PointStateType.Finished)
            {
                Clicked.Invoke(this, new ListItemClickedEventArgs(Text, Index));
            }

            return true;
        }

        public void ChangeSelectionState(bool selected)
        {
            if (selected == true)
            {
                BackgroundColor = new Color(0.5f, 0.5f, 0.5f, 0.5f); ;
            }
            else
            {
                BackgroundColor = Color.White;
            }
        }
    }

    public partial class FlexPage2 : View
    {
        private readonly int ItemCount = 20;
        private int SelectedItemIndex = -1;
        private List<ListItem> items;

        public FlexPage2()
        {
            InitializeComponent();
            items = new List<ListItem>();


            for (int i = 0; i < ItemCount; ++i)
            {
                ListItemPage listItemPage = new ListItemPage();
                ListView.Add(listItemPage);

                //items.Add(new ListItem(string.Format("{0}th list item", i + 1), i));
                //items[i].Clicked += OnClicked;
                //ListView.Add(items[i]);
            }

            Title.Text = ItemCount.ToString() + " tracks";
        }

        private void OnClicked(object sender, ListItemClickedEventArgs args)
        {
            //Title.Text = args.ClickedItemText;

            if (SelectedItemIndex != -1)
            {
                items[SelectedItemIndex].ChangeSelectionState(false);
            }

            SelectedItemIndex = args.Index;
            items[SelectedItemIndex].ChangeSelectionState(true);

        }
    }
}
