﻿using Tizen.NUI;
using Tizen.NUI.BaseComponents;

namespace NUIScalableViews.layout
{
    public partial class ListItemPage : View
    {
        public ListItemPage()
        {
            InitializeComponent();
        }
    }
}
