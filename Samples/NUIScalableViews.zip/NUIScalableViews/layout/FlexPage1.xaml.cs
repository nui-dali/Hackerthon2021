﻿using Tizen.NUI;
using Tizen.NUI.BaseComponents;

namespace NUIScalableViews
{
    public partial class FlexPage1 : View
    {
        public FlexPage1()
        {
            InitializeComponent();
        }
    }
}
